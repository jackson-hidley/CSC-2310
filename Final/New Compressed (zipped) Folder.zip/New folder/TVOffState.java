public class TVOffState implements TVState{
  
   @Override
   public void doAction() {
       System.out.println("TV is in OFF State");
   }

}