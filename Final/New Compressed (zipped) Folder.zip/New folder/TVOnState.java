public class TVOnState implements TVState{

   @Override
   public void doAction() {
       System.out.println("TV is in ON State");
   }

}