public interface TVState {
void doAction();
}