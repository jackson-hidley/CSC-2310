import java.util.ArrayList;

interface Post
{
    public void postMessage(String message);
}