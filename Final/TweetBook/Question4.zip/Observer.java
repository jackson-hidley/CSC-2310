public interface Observer {
    public void update();       // To update each friend about status
}