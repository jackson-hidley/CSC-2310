//concrete element
public class CSAnalyst implements Visitable
{
	private String name;
	private double income;
	private int vacaDays; 

	CSAnalyst( String name, double income, int vacaDays )
	{
		this.name = name;
		this.income = income;
		this.vacaDays = vacaDays;
	}
	
	//accept the visitor
	public void accept(Visitor visitor)
	{
		visitor.visit(this);
	}
	
	public String getName()
	{
		return name;
	}
  
	public double getIncome()
	{
		return income;
	}
  
	public int getVacaDays()
	{
		return vacaDays;
	}
} 