public class IncomeVisitor implements Visitor
{
	private double newIncome;
	
	public void visit( SoftwareDev softwareDev )
	{
		newIncome = softwareDev.getIncome() * 1.30; //increase income by 30%
	}
	
	public void visit( DatabaseAdmin databaseAdmin )
	{
		newIncome = databaseAdmin.getIncome() * 0.90; //decrease income by 10%
	}
	
	public void visit( CSAnalyst cSAnalyst )
	{
		newIncome = cSAnalyst.getIncome() * 1.30; //increase income by 30%
	}
	
	public void visit( WebDev webDev )
	{
		newIncome = webDev.getIncome() * 0.90; //decrease income by 10%
	}
	
	public void visit( ISA isa )
	{
		newIncome = isa.getIncome() * 1.50; //increase income by 50%
	}
	
	public double getNewIncome()
	{
		return newIncome; //return the new income
	}
}