import java.util.ArrayList;



public class JobClient
{
	
	private static Keyboard kb = Keyboard.getKeyboard();
	
	private static ArrayList<Visitable> jobs;
	
	private static IncomeVisitor iv = new IncomeVisitor();
	private static VacationVisitor vv = new VacationVisitor();
	private static NameVisitor nv = new NameVisitor();	
	

	public static void main(String[] args)
	{

		jobs = new ArrayList<Visitable>();
		
		int awn = 1;
		
		while(awn != 0) 
		{
			awn = kb.readInt(jobs.size() + " job(s). Make a selection: \r\n(1) Add Job \r\n(2) Visit\r\n(0) Exit\r\n");
		
			if(awn == 1) {
				addJob();
			}
			else if(awn == 2) {
				int awn2 = kb.readInt("Make a selection: \r\n(1) income Visitor \r\n(2) Vacation Visitor\r\n(3) Name Visitor\r\n(4) All Visitors\r\n");
				
				if(awn2 == 1) {
					visit(iv);
				}
				else if(awn2 == 2) {
					visit(vv);
				}
				else if(awn2 == 3) {
					visit(nv);
				}
				else {
					visitAll();
				}
			}
			else {
				return;
			}
		}
	}
	
	public static void addJob() 
	{
		//prompt user
		int awn = 0;
		String name;
		double income;
		int vacaDays;
		Visitable job = null;
		while(awn < 1 || awn > 5)
		{
			awn = kb.readInt("Which type of job would you like to create: \n(1) Software Developer\n(2) Database Administrator\n(3) Computer Systems Analyst\n(4) Web Developer\n(5) Information Security Analyst\n\r");
	
		}

		name = kb.readString("Name: ");
		income = kb.readDouble("Income: ");
		vacaDays = kb.readInt("Vacation Days: ");			
		
		
		if(awn == 1)
		{
			job = new SoftwareDev(name, income, vacaDays);
		}
		else if(awn == 2) 
		{
			job = new DatabaseAdmin(name, income, vacaDays);				
		}
		else if(awn == 3) 
		{
			job = new CSAnalyst(name, income, vacaDays);			
		}
		else if(awn == 4) 
		{
			job = new WebDev(name, income, vacaDays);			
		}
		else 
		{
			job = new ISA(name, income, vacaDays);			
		}
		
		
		jobs.add(job);
	}
	
	
	public static void visit(Visitor visitor) 
	{
		for(Visitable job : jobs) {
			job.accept(visitor);
			displayVisit();
		}
	}
	
	public static void visitAll() 
	{
		for(Visitable job : jobs) 
		{
			job.accept(iv);
			job.accept(vv);
			job.accept(nv);
			displayVisit();
		}
	}	

	public static void displayVisit() 
	{

		double newIncome = iv.getNewIncome();
		System.out.println("New Income: " + newIncome);
	
		int newVacaDays = vv.getNewVacaDays();
		System.out.println("New Vacation Days: " + newVacaDays);		
		
		String newName = nv.getNewName();
		System.out.println("New Name: " + newName);	
	}
	

}