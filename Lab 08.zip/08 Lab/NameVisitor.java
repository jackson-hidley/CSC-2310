public class NameVisitor implements Visitor
{
	private String newName;
	
	public void visit( SoftwareDev softwareDev )
	{
		newName = (softwareDev.getName() + " the SoftDev" );
	}
	
	public void visit( DatabaseAdmin databaseAdmin )
	{
		newName = (databaseAdmin.getName() + " the Admin" );
	}
	
	public void visit( CSAnalyst cSAnalyst )
	{
		newName = (cSAnalyst.getName() + " (C.S.A.)" );
	}
	
	public void visit( WebDev webDev )
	{
		newName = (webDev.getName() + " the WebDev" );
	}
	
	public void visit( ISA isa )
	{
		newName = (isa.getName() + " (I.S.A.)" );
	}
	
	public String getNewName()
	{
		return newName;
	}
}