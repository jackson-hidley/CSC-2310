public class VacationVisitor implements Visitor
{
	private int newVaca;
	
	public void visit( SoftwareDev softwareDev )
	{
		//if vacation days is even add 2, else subtract 1
		if( (softwareDev.getVacaDays() % 2) == 0 )
			newVaca = softwareDev.getVacaDays() + 2;
		else
			newVaca = softwareDev.getVacaDays() - 1;
	}
	
	public void visit( DatabaseAdmin databaseAdmin )
	{
		//if vacation days is even add 2, else subtract 1
		if( (databaseAdmin.getVacaDays() % 2) == 0 )
			newVaca = databaseAdmin.getVacaDays() + 2;
		else
			newVaca = databaseAdmin.getVacaDays() - 1;
	}
	
	public void visit( CSAnalyst cSAnalyst )
	{
		newVaca = 365; //soft firing
	}
	
	public void visit( WebDev webDev )
	{
		newVaca = 0; //overworking
	}
	
	public void visit( ISA isa )
	{
		//if vacation days is even add 2, else subtract 1
		if( (isa.getVacaDays() % 2) == 0 )
			newVaca = isa.getVacaDays() + 2;
		else
			newVaca = isa.getVacaDays() - 1;
	}
	
	public int getNewVacaDays()
	{
		return newVaca; //return the new number of vacation days
	}
}