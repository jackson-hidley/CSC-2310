public interface Visitor
{
	public void visit( SoftwareDev softwareDev );
	public void visit( DatabaseAdmin databaseAdmin );
	public void visit( CSAnalyst cSAnalyst );
	public void visit( WebDev webDev );
	public void visit( ISA isa );
}