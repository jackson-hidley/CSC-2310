//place this file in the ki subdirectory
package ki;

public abstract class KeyedItem
{
	//create private instance variable of type Comparable
	private Comparable item; 
  
   public KeyedItem(Comparable key) 
   {
		item = key;
   }  

   public Comparable getKey() 
   {
	   return item;
   }  

   //Use Comparable's toString() method
   public String toString()
   {
		return item.toString();
   }
}