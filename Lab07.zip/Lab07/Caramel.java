

public class Caramel extends Beverage {
	public Caramel() {
		description = "Caramel Coffee";
	}
 
	public double cost() {
		return 1.35;
	}
}