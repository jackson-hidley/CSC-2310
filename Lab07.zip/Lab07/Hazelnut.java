

public class Hazelnut extends Beverage {
	public Hazelnut() {
		description = "Hazelnut Coffee";
	}
 
	public double cost() {
		return 1.25;
	}
}