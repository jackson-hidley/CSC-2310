import java.awt.event.*; 
import javax.swing.*; 
import java.awt.*; 
import java.lang.Math;

public class AdvancedCalculator extends JFrame implements ActionListener
{
	static JFrame frame;
	static JTextField textField;
	String num1, operand, num2;
	
	AdvancedCalculator()
	{
		num1 = "";
		operand = "";
		num2 = "";
	}
	
	public static void main( String[] args )
	{
		//GUI
		frame = new JFrame( "Advanced Calculator" );
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		frame.setLayout( new BorderLayout() );
		textField = new JTextField(20); 
		textField.setEditable( false ); 
		JPanel panel = new JPanel(); 
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel(); 
		AdvancedCalculator calculator = new AdvancedCalculator();
		
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
		}
		
		//Buttons
		JButton b_0 = new JButton("0");
		JButton b_1 = new JButton("1");
		JButton b_2 = new JButton("2");
		JButton b_3 = new JButton("3");
		JButton b_4 = new JButton("4");
		JButton b_5 = new JButton("5");
		JButton b_6 = new JButton("6");
		JButton b_7 = new JButton("7");
		JButton b_8 = new JButton("8");
		JButton b_9 = new JButton("9");
		JButton b_clear = new JButton("Clear");
		JButton b_dot = new JButton(".");
		JButton b_equals = new JButton("=");
		JButton b_add = new JButton("+");
		JButton b_sub = new JButton("-");
		JButton b_mul = new JButton("x");
		JButton b_div = new JButton("/");
		JButton b_inv = new JButton("x-1");
		JButton b_sin = new JButton("sin()");
		JButton b_cos = new JButton("cos()");
		JButton b_sinh = new JButton("sinh");
		JButton b_cosh = new JButton("cosh");
		JButton b_tanh = new JButton("tanh");
		JButton b_sqrt = new JButton("SqRoot");
		JButton b_square = new JButton("x2");
		JButton b_cube = new JButton("x3");
		JButton b_x_to_y = new JButton("x^y");
		JButton b_abs = new JButton("abs");
	
		//Activate button when pushed
		b_0.addActionListener( calculator );
		b_1.addActionListener( calculator );
		b_2.addActionListener( calculator );
		b_3.addActionListener( calculator );
		b_4.addActionListener( calculator );
		b_5.addActionListener( calculator );
		b_6.addActionListener( calculator );
		b_7.addActionListener( calculator );
		b_8.addActionListener( calculator );
		b_9.addActionListener( calculator );
		b_clear.addActionListener( calculator );
		b_dot.addActionListener( calculator );
		b_equals.addActionListener( calculator );
		b_add.addActionListener( calculator );
		b_sub.addActionListener( calculator );
		b_mul.addActionListener( calculator );
		b_div.addActionListener( calculator );
		b_inv.addActionListener( calculator );
		b_sin.addActionListener( calculator );
		b_cos.addActionListener( calculator );
		b_sinh.addActionListener( calculator );
		b_cosh.addActionListener( calculator );
		b_tanh.addActionListener( calculator );
		b_sqrt.addActionListener( calculator );
		b_square.addActionListener( calculator );
		b_cube.addActionListener( calculator );
		b_x_to_y.addActionListener( calculator );
		b_abs.addActionListener( calculator );
		
		//add our buttons to panel
		panel.add( textField );
		
		panel.add( b_1);
		panel.add( b_2);
		panel.add( b_3);
		panel.add( b_4);
		panel.add( b_5);
		panel.add( b_6);
		panel.add( b_7);
		panel.add( b_8);
		panel.add( b_9);
		panel.add( b_0);
		panel.add( b_dot);
		panel.add( b_clear);
		
		panel.add( b_equals );
		panel.add( b_add );
		panel.add( b_sub );
		panel.add( b_mul );
		panel.add( b_div );
		panel.add( b_inv );
		panel.add( b_sin );
		panel.add( b_cos );
		panel.add( b_sinh );
		panel.add( b_cosh );
		panel.add( b_tanh );
		panel.add( b_sqrt );
		panel.add( b_square );
		panel.add( b_cube );
		panel.add( b_x_to_y );
		panel.add( b_abs );
		
		//set size of calculator
		frame.add( panel );
		frame.setSize( 250,275 ); // height, width
		frame.show();
			
	}
	public void actionPerformed(ActionEvent event)
	{
		String item = event.getActionCommand();
		String total = "";
		double value = 0;
		double a = 0;
		double b = 0;
		
		//if num is number or decimal
		if( (item.charAt(0) >= '0' && item.charAt(0) <= '9') || item.charAt(0) == '.' )
		{
			// if no operand 
			if( operand.equals("") )
			{
				num1 = num1 + item;
			}
			else if( !operand.equals("") )
			{
				num2 = num2 + item;
			}
			
			textField.setText( num1 + operand + num2 );
		}
		else if(item.charAt(0) == 'C') // Clear all values
		{
			num1 = "";
			a = 0;
			operand = "";
			num2 = "";
			b = 0;
			
			textField.setText( num1 + operand + num2 );
		}
		else if(item.charAt(0) == '=')
		{
			
			a = Double.parseDouble( num1 );
			if( num2.equals("") )
			{
				b = 0;
			}
			else
			{
				b = Double.parseDouble(num2);
			}
			
			
			if( operand.equals("+") )
			{
				value = a + b;
			}
			else if( operand.equals("-") )
			{
				value = a - b;
			}
			else if( operand.equals("x") )
			{
				value = a * b;
			}
			else if( operand.equals("/") )
			{
				value = a / b;
			}
			else if( operand.equals("x^y") )
			{
				value = Math.pow(a, b);
			}
			else if( operand.equals("sin()") )
			{
				value = Math.sin(a);
			}
			else if( operand.equals("cos()") )
			{
				value = Math.cos(a);
			}
			else if( operand.equals("sinh") )
			{
				value = Math.sinh(a);
			}
			else if( operand.equals("cosh") )
			{
				value = Math.cosh(a);
			}
			else if( operand.equals("tanh") )
			{
				value = Math.tanh(a);
			}
			else if( operand.equals("x-1") )
			{
				value = 1 / a;
			}
			else if( operand.equals("SqRoot") )
			{
				value = Math.sqrt(a);
			}
			else if( operand.equals("x2") )
			{
				value = Math.pow(a, 2);
			}
			else if( operand.equals("x3") )
			{
				value = Math.pow(a, 3);
			}
			else if( operand.equals("abs") )
			{
				value = Math.abs(a);
			}
			
			System.out.println( value );
			textField.setText( num1 + operand + num2 + "=" + value );
			num1 = Double.toString( value ); 
			operand = "";
			num2 = "";
			
		}
		
		else
		{
			if( operand.equals("") )
			{
				operand = item;
			}
			else
			{
				a = Double.parseDouble(num1);
				if( num2.equals("") )
				{
					b = 0;
				}
				else
				{
					b = Double.parseDouble(num2);
				}
				
				if( operand.equals("+") )
				{
					value = a + b;
				}
				else if( operand.equals("-") )
				{
					value = a - b;
				}
				else if( operand.equals("x") )
				{
					value = a * b;
				}
				else if( operand.equals("/") )
				{
					value = a / b;
				}
				else if( operand.equals("x^y") )
				{
					value = Math.pow(a, b);
				}
				
				num1 = Double.toString(value); 
				operand = item;
				num2 = "";
			}
			textField.setText( num1 + operand + num2 );
		}
	}
}