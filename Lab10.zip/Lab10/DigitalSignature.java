import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.InvalidKeyException;

public class DigitalSignature
{
	private String keyAlgorithm;
	private String provider;
	private String signingAlgorithm;
	private int keysize;
	
	public DigitalSignature( String keyAlgorithm, String provider, String signingAlgorithm, int keysize )
	{
		this.keyAlgorithm = keyAlgorithm;
		this.provider = provider;
		this.signingAlgorithm = signingAlgorithm;
		this.keysize = keysize;
	}
	
	public KeyPair getKeyPair() 
	{
		try
		{
			SecureRandom secureRandom = new SecureRandom();
			KeyPairGenerator generator = KeyPairGenerator.getInstance( keyAlgorithm, provider );
			generator.initialize( keysize, secureRandom );
			return generator.generateKeyPair();
		}
		catch ( NoSuchAlgorithmException e )
		{
			System.out.println(e);
			return null;
		}
		catch ( NoSuchProviderException e )
		{
			System.out.println(e);
			return null;
		}
	}
	
	public byte[] getSignature( String data, PrivateKey key )
	{
		try
		{
			Signature signature = Signature.getInstance( signingAlgorithm, provider );
			signature.initSign(key);
			signature.update(data.getBytes());
			return signature.sign();
		}
		catch ( NoSuchAlgorithmException e )
		{
			System.out.println(e);
			return null;
		}
		catch ( InvalidKeyException e )
		{
			System.out.println(e);
			return null;
		}
		catch ( SignatureException e )
		{
			System.out.println(e);
			return null;
		}
		catch ( NoSuchProviderException e )
		{
			System.out.println(e);
			return null;
		}
		
	}
	
	public boolean verify(String data, byte[] signatureToVerify, PublicKey key)
	{
		try
		{
			Signature realSignature = Signature.getInstance( signingAlgorithm, provider );
			realSignature.initVerify(key);
			realSignature.update( data.getBytes() );
			
			return realSignature.verify( signatureToVerify );
		}
		catch ( NoSuchAlgorithmException e )
		{
			System.out.println(e);
			return false;
		}
		catch ( InvalidKeyException e )
		{
			System.out.println(e);
			return false;
		}
		catch ( SignatureException e )
		{
			System.out.println(e);
			return false;
		}
		catch ( NoSuchProviderException e )
		{
			System.out.println(e);
			return false;
		}
	}
}