import java.util.ArrayList;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class MerkleTree
{
	
	public static String getMerkleRoot( ArrayList<String> data )
	{
		ArrayList<String> hashList = getSHAList(data);
		ArrayList<String> merkleTree = makeMerkleRoot(hashList);
		return merkleTree.get(0);
	}
	
	private static ArrayList<String> getSHAList( ArrayList<String> list )
	{
		String hashString;
		ArrayList<String> hashList = new ArrayList<>();
		for ( String data : list )
		{
			hashString = getSHA(data);
			hashList.add(hashString);
		}
		return hashList;
	}
	
	private static String getSHA( String data )
	{
		byte[] hashByteArray;
		BigInteger hashBigInteger;
		String hashString = null;
		try
		{
			MessageDigest md = MessageDigest.getInstance( "SHA-256" );
			hashByteArray = md.digest( data.getBytes() );
			hashBigInteger = new BigInteger( 1, hashByteArray );
			hashString = hashBigInteger.toString(16);
			while ( hashString.length() < 32 )
			{
				hashString = "0" + hashString;
			}
		}
		catch ( NoSuchAlgorithmException e )
		{
			System.out.println( "Incorrect algorithm exception" + e );
			System.exit(1);
		}
		return hashString;
	}
	
	private static ArrayList<String> makeMerkleRoot( ArrayList<String> hashList )
	{
		if ( hashList.size() == 1 )
		{
			return hashList;
		}
		String parentHash;
		ArrayList<String> parentHashList = new ArrayList<>();
		if (hashList.size() % 2 == 1)
		{
			hashList.add( hashList.get( hashList.size() - 1 ) );
		}
		for (int i = 0; i < hashList.size(); i += 2)
		{ 
			parentHash = getSHA( hashList.get(i) + hashList.get(i+1) );
			parentHashList.add( parentHash );
		}
		return makeMerkleRoot( parentHashList );
	}
	
}