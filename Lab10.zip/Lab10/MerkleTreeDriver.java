import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.security.KeyPair;


public class MerkleTreeDriver
{
	
	public static ArrayList<String> readCVS( String fileName )
	{
		String token;
		ArrayList<String> list = new ArrayList<>();
		try
		{
			Scanner scanner = new Scanner( new File(fileName) );
			scanner.useDelimiter(",");
			while ( scanner.hasNext() )
			{
				token = scanner.next();
				token = token.trim();
				list.add(token);
			}
			scanner.close();
		}
		catch ( FileNotFoundException e )
		{
			System.out.println( "File not found" + e );
			System.exit(1);
		}
		return list;
	}
	
	public static void main( String[] args )
	{
		String merkleRoot, tamperedMerkleRoot;
		byte[] professorSignature, friendSignature;
		KeyPair professorKeyPair, friendKeyPair;
		ArrayList<String> grades = new ArrayList<>();
		
		grades = readCVS( "input.csv" );
		merkleRoot = MerkleTree.getMerkleRoot( grades );
		
		grades = readCVS("tamperedInput.csv");
		tamperedMerkleRoot = MerkleTree.getMerkleRoot( grades );

		DigitalSignature dsa = new DigitalSignature( "DSA", "SUN", "SHA256withDSA", 2048 );

		professorKeyPair = dsa.getKeyPair();
		professorSignature = dsa.getSignature( merkleRoot, professorKeyPair.getPrivate() );
		System.out.println( "Professor's signature: " + professorSignature );
		
		if ( dsa.verify( merkleRoot, professorSignature, professorKeyPair.getPublic() ) )
		{
			System.out.println( "verified" );
		}
		
		else
		{
			System.out.println( "not verified" );
		}
		friendKeyPair = dsa.getKeyPair();
		friendSignature = dsa.getSignature( tamperedMerkleRoot, friendKeyPair.getPrivate() );
		System.out.println( "\nFriend's signature: " + friendSignature );
		if (dsa.verify( tamperedMerkleRoot, friendSignature, professorKeyPair.getPublic() ) )
			System.out.println( "verified" );
		else
			System.out.println( "not verified" );
	}
}