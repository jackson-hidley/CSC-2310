
public interface ToppingSelected
{
   public void toppingSelected(String topping);
}