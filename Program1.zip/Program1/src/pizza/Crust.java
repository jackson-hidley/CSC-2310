package pizza;

public class Crust
{
	CrustSize size;
	CrustType type;
	
	//Constructor
	Crust( CrustSize s, CrustType t )
	{
		this.size = s;
		this.type = t;
	}
	
	public double crustCost()
	{
		return this.size.price() + this.type.price();
	}
	
	public String toString()
	{
		return "\nSize: " + size + "\nCrust: " + type + "\nToppings: ";
	}
	
	public String getCrust()
	{
		String crustType = type.toString();
		return crustType;
	}
	
	public char getSize()
	{
		String crustSize = size.toString();
		return crustSize.charAt(0);
	}
}