package pizza;

enum CrustSize
{
	S(5.99), M(7.99), L(9.99);

	private double CrustSizePrice;
	
	private CrustSize(double price) 
   {
      CrustSizePrice = price;
   }

   public double price()
   {
      return CrustSizePrice;
   }
}

enum CrustType
{
	THIN(0.00), HAND(0.50), PAN(1.00);
	
	private double CrustTypePrice;
	
	private CrustType(double price) 
   {
      CrustTypePrice = price;
   }

   public double price()
   {
      return CrustTypePrice;
   }
}