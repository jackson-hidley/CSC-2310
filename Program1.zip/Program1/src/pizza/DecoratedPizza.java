package pizza;

abstract class DecoratedPizza
{
	private DecoratedPizza next_pizza_item;
	
	DecoratedPizza()
	{
		next_pizza_item = null;
	}
	
	DecoratedPizza( DecoratedPizza p )
	{
		next_pizza_item = p;
	}
	
	public double pizzaCost()
	{
		return next_pizza_item.pizzaCost();
	}
	
	public String toString()
	{
		return next_pizza_item.toString();
	}
	
	public String getImage()
	{
		return next_pizza_item.getImage();
	}
}