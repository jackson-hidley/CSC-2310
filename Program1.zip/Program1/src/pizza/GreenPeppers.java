package pizza;

public class GreenPeppers extends DecoratedPizza
{
	Pizza pizza;
	
	public GreenPeppers(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", GreenPeppers";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.69);
	}
}