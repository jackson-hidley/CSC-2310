package pizza;

public class Ham extends DecoratedPizza
{
	Pizza pizza;
	public Ham(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Ham";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.89);
	}
}