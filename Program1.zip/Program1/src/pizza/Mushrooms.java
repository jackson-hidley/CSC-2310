package pizza;

public class Mushrooms extends DecoratedPizza
{
	Pizza pizza;
	public Mushrooms(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Mushrooms";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.79);
	}
}