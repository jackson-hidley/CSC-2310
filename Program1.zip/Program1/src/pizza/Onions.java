package pizza;

public class Onions extends DecoratedPizza
{
	Pizza pizza;
	public Onions(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Onions";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.79);
	}
}