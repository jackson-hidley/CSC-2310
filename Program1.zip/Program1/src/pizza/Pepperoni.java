package pizza;

public class Pepperoni extends DecoratedPizza
{
	Pizza pizza;
	public Pepperoni(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Pepperoni";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.99);
	}
}