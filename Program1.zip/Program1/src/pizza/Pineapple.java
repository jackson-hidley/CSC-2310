package pizza;

public class Pineapple extends DecoratedPizza
{
	Pizza pizza;
	public Pineapple(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Pinapple";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.89);
	}
}