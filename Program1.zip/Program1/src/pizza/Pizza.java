package pizza;

public class Pizza extends DecoratedPizza
{
	private Crust crust;
	
	public Pizza( Crust c )
	{
		super();
		this.crust = c;
	}
	
	public double pizzaCost()
	{
		return this.crust.crustCost();
	}
	
	public String toString()
	{
		return this.crust.toString();
	}
	
	public String getImage()
	{
		String image = "" + this.crust.getSize();
		return image;
	}
}
