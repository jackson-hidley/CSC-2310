package pizza;

public class PizzaBuilder
{
	private DecoratedPizza toplink;
	private CrustSize cSize;
	private CrustType cType;
	
	//create a Crust and a Pizza using that Crust based on the user's specifications (the Pizza is now ready for toppings)
	protected void buildPizza()
	{
		Crust crust = new Crust( cSize, cType );
		toplink = new Pizza( crust );
	}
	
	//start with a small, thin pizza with no toppings as the default
	public PizzaBuilder()
	{
		cSize = CrustSize.S;
		cType = CrustType.THIN;
		Crust crust = new Crust( cSize, cType );
		toplink = new Pizza( crust );
	}
	
	//returns true if the input was valid ("S" or "small", etc., not case sensitive, use the String charAt method to get the first character)
	public boolean setSize( char try_size )
	{
		boolean valid;
		
		if( try_size == 'S' )
		{
			cSize = CrustSize.S;
			buildPizza();
			valid = true;
		}
		
		else if( try_size == 'M' )
		{
			cSize = CrustSize.M;
			buildPizza();
			valid = true;
		}
		
		else if( try_size == 'L' )
		{
			cSize = CrustSize.L;
			buildPizza();
			valid = true;
		}
		
		else
		{
			valid = false;
		}
		
		return valid;
	}
	
	//("thin", "hand", or "pan", not case sensitive)
	public boolean setCrust( String try_crust )
	{
		boolean valid;
		
		if( try_crust.compareTo( "THIN" ) == 0 )
		{
			cType = CrustType.THIN;
			buildPizza();
			valid = true;
		}
		
		else if(  try_crust.compareTo( "HAND" ) == 0 )
		{
			cType = CrustType.HAND;
			buildPizza();
			valid = true;
		}
		
		else if (  try_crust.compareTo( "PAN" ) == 0 )
		{
			cType = CrustType.HAND;
			buildPizza();
			valid = true;
		}
		
		else
		{
			valid = false;
		}
		
		return valid;
	}
	//compare the topping abbreviation to topping_char to determine which topping to add (using void here is convenient for the PizzaDriver, ignore invalid abbreviations)
	public void addTopping( char topping_char )
	{
		if(toplink instanceof Pizza || toplink instanceof PizzaTopping)
		{
			if(topping_char == 'P')
			{
				toplink = PizzaToppingFactory.addPepperoni(toplink);
			}
			else if(topping_char == 'S')
			{
				toplink = PizzaToppingFactory.addSausage(toplink);
			}
			else if(topping_char == 'O')
			{
				toplink = PizzaToppingFactory.addOnions(toplink);
			}
			else if(topping_char == 'G')
			{
				toplink = PizzaToppingFactory.addGreenPeppers(toplink);
			}
			else if(topping_char == 'M')
			{
				toplink = PizzaToppingFactory.addMushrooms(toplink);
			}
			else if(topping_char == 'A')
			{
				toplink = PizzaToppingFactory.addPineapple(toplink);
			}
			else if(topping_char == 'H')
			{
				toplink = PizzaToppingFactory.addHam(toplink);
			}
		}
	}
	
	//return the final DecoratedPizza and reset to the default pizza if another pizza is desired
	public DecoratedPizza pizzaDone()
	{
		DecoratedPizza pizza = toplink;
		toplink = null;
		return pizza;
	}
	
	//give a discount to the pizza(s)
	public void addDiscount(String msg, double dis)
	{
		if(toplink instanceof PizzaDiscount || toplink instanceof Pizza || toplink instanceof PizzaTopping)
		{
			toplink = new PizzaDiscount(toplink, msg, dis);
		}
	}
	
	//add a fee to the pizza(s)
	public void addFee(String msg, double fee)
	{
		if(toplink instanceof PizzaDiscount || toplink instanceof Pizza || toplink instanceof PizzaTopping)
		{
			toplink = new PizzaFee(toplink, msg, fee);
		}
	}
	
}