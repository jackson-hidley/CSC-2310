package pizza;

public class PizzaDiscount extends DecoratedPizza
{
	private double pizzaDiscount;
	private String message;
	
	public PizzaDiscount( DecoratedPizza pizza_component, String msg, double discount )
	{
		super( pizza_component );
		
		this.pizzaDiscount = discount;
		this.message = msg;
	}
	
	public double pizzaCost()
	{
		return super.pizzaCost() * pizzaDiscount;
	}
 
	public String toString()
	{
		return super.toString() + "\n" + this.message;
	}
}