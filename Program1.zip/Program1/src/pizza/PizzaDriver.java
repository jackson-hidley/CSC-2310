package pizza;


import util.Keyboard;
import java.text.DecimalFormat;

public class PizzaDriver
{
	static private Keyboard k = Keyboard.getKeyboard();
	static double total = 0;
	
	//show the menu choices, wait for and return the valid selection
	private static int menu()
	{
		int awn;
		boolean valid;
		
		do
		{
			System.out.println( "\n1. Meat Lover's" + "\n2. Veggie Lover's" + "\n3. Hawaiian" + "\n4. Build Your Own" );
			awn = k.readInt( "CHOICE: " );
			
			if( awn >= 1 || awn <= 4 )
				valid = true;
			else
			{
				System.out.println( "\nInvalid input. Please try again.\n" );
				valid = false;
			}
		}while( !valid );
		
		return awn;
	}
	
	//request the crust size, wait for a valid response confirmation from PizzaBuilder
	private static void requestSize( PizzaBuilder pizza_builder )
	{
		boolean valid;
		String size;
		
		do
		{
			size = k.readString( "\nWhat size pizza (S/M/L)?\nCHOICE: " );
			size = size.toUpperCase();
			valid = pizza_builder.setSize( size.charAt(0) );
		
		}while( !valid );
	}
	
	private static void requestCrust( PizzaBuilder pizza_builder )
	{
		boolean valid;
		String crust;
		
		do
		{
			crust = k.readString( "\nWhat type of crust (thin/hand/pan)?\nCHOICE: " );
			crust = crust.toUpperCase();
			valid = pizza_builder.setCrust( crust );
			
		}while(!valid);
	}
	
	//ask for toppings until Done indicated (invalid toppings are ignored)
	private static void requestToppings( PizzaBuilder pizza_builder )
	{
		boolean done;
		String topping;
		
		do
		{
			topping = k.readString("\n(P)epperoni,(O)nions,(G)reen Peppers,(S)ausage,(M)ushrooms,(D)one\n");
			topping = topping.toUpperCase();
			
			if( topping.equals( "D" ) )
				done = true;
			else
				done = false;
		
		}while( !done );
	}
	
	//display the pizza and its total cost
	private static void showOrder( DecoratedPizza dec_pizza )
	{
		System.out.println( "\nYour pizza:\n" + dec_pizza.toString() );
		
		DecimalFormat cost = new DecimalFormat( "#.##" );
		
		System.out.println( "\n\nThe cost of your pizza is $" + cost.format( dec_pizza.pizzaCost() ) );
		total += dec_pizza.pizzaCost();
	}	
	
	public static void main( String[] args )
	{
		PizzaBuilder pizza = new PizzaBuilder();
		int pizzaCount = 0;
		
		String awn;
		awn = k.readString("\nWould you like to order a pizza (y/n)? ");
	  	awn = awn.toUpperCase();
		
		while( awn.charAt(0) == 'Y' )
		{
			pizzaCount++;
			
			int choice = menu();
			
			if( choice == 1 )
			{
				pizza = new MeatLovers();
				requestSize( pizza );
				requestCrust( pizza );
				pizza.buildPizza();
			}
			
			else if( choice == 2 )
			{
				pizza = new VeggieLovers();
				requestSize( pizza );
				requestCrust( pizza );
				pizza.buildPizza();
			}
			
			else if( choice == 3 )
			{
				pizza = new Hawaiian();
				requestSize( pizza );
				requestCrust( pizza );
				pizza.buildPizza();
			}
			else if( choice == 4 )
			{
				pizza = new PizzaBuilder();
				requestSize( pizza );
				requestCrust( pizza );
				pizza.buildPizza();
				requestToppings( pizza );
			}
			
			String seniorDiscount = k.readString( "\nAre you a senior citizen?/n(Y/N): " );
			seniorDiscount = seniorDiscount.toUpperCase();
			if( seniorDiscount.charAt(0) == 'Y' )
			{
				pizza.addDiscount( "Senior Citizen", 0.9 );
			}
			
			String deliveryFee = k.readString( "Do you need this pizza delivered?/n(Y/N): " );
			deliveryFee = deliveryFee.toUpperCase();
			if( deliveryFee.charAt(0) == 'Y' )
			{
				pizza.addFee( "Delivery", 2.50) ;
			}
			
			DecoratedPizza decoratedPizza = pizza.pizzaDone();
			
			showOrder(decoratedPizza);
			
			awn = k.readString( "\nWould you like to order a pizza?/n(Y/N): " );
			awn = awn.toUpperCase();
		}
	   
		DecimalFormat cost = new DecimalFormat( "#.##" );
		System.out.println( "You ordered " + pizzaCount + " pizza(s) for a grand total of $" + cost.format( total ) + "." );
   }
}