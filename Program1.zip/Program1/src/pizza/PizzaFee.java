package pizza;

public class PizzaFee extends DecoratedPizza
{
	private double pizzaFee;
	private String message;
	
	public PizzaFee( DecoratedPizza pizza_component, String msg, double fee )
	{
		super( pizza_component );
		this.pizzaFee = fee;
		this.message = msg;
	}
	
	public double pizzaCost()
	{
		return super.pizzaCost() + this.pizzaFee;
	}
 
	public String toString()
	{
		return super.toString() + "\n" + this.message;
	}
};