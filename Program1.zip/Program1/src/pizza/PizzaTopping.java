package pizza;

public class PizzaTopping extends DecoratedPizza
{
	private double cost;
	private String string;
	private String letter;
		
	public PizzaTopping( DecoratedPizza pizza_component, String topping_string, String topping_letter, double topping_cost )
	{
		super(pizza_component);
		cost = topping_cost;
		string = topping_string;
		letter = topping_letter;
	}
	
	public double pizzaCost()
	{
		return cost + super.pizzaCost();
	}
 
	public String toString()
	{
		return super.toString() + "\n" + string;
	}
	
	public String getImage()
	{
		return super.getImage() + letter;
	}
}