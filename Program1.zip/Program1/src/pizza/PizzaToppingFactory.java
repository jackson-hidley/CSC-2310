package pizza;

class PizzaToppingFactory
{
	public static DecoratedPizza addPepperoni(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Pepperoni", "P", 0.99);
	}
	
	public static DecoratedPizza addSausage(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Sausage", "S", 0.99);
	}
	
	public static DecoratedPizza addOnions(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Onions", "O", 0.79);
	}
	
	public static DecoratedPizza addMushrooms(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Mushrooms", "M", 0.79);
	}
	
	public static DecoratedPizza addHam(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Ham", "H", 0.89);
	}
	
	public static DecoratedPizza addPineapple(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "Pineapple", "A", 0.89);
	}
	public static DecoratedPizza addGreenPeppers(DecoratedPizza dec_pizza)
	{
		return new PizzaTopping(dec_pizza, "GreenPeppers", "G", 0.69);
	}
}