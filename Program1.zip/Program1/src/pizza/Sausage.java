package pizza;

public class Sausage extends DecoratedPizza
{
	Pizza pizza;
	public Sausage(Pizza p)
	{
		this.pizza = p;
	}
	
	public String toString()
	{
		return pizza.toString() + ", Sausage";
	}
	
	public double pizzaCost()
	{
		return pizza.pizzaCost() + (0.99);
	}
}