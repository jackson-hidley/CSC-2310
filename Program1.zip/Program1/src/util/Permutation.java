package util;

public interface Permutation
{
   public boolean hasNext();
   public int next();
}
