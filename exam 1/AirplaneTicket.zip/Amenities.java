public abstract class Amenities {
	String description = "NO Amenities";
  
	public String getDescription() {
		return description;
	}
 
	public abstract double cost();
}
