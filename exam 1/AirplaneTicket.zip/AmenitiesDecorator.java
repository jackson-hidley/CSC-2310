public abstract class AmenitiesDecorator extends Amenities {
	public abstract String getDescription();
}